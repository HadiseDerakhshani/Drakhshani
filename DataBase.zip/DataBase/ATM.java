public class ATM {
    Customer[] customer = new Customer[100];
    static String adminUsername = "admin";
    static String adminPassword = "admin";
    static int indexOfCustomer = 0;

    public ATM() {
        for (int i = 0; i < 100; i++) {
            customer[i] = new Customer();
        }
    }

    public void addCustomer(String name, String family, long id,
                            String username, String password, long funds) {
        customer[indexOfCustomer].setName(name);
        customer[indexOfCustomer].setFamily(family);
        customer[indexOfCustomer].setId(id);
        customer[indexOfCustomer].setUsername(username);
        customer[indexOfCustomer].setPassword(password);
        customer[indexOfCustomer].setFunds(funds);
        indexOfCustomer++;
    }

    public void printAllCustomer() {
        for (int i = 0; i < indexOfCustomer; i++) {
            System.out.println("Customer Name[" + i + "]:" + customer[i].getName()
                    + " Customer Family[" + i + "]:" + customer[i].getFamily()
                    + " Customer ID[" + i + "]:" + customer[i].getId()
                    + " Customer Username[" + i + "]:" + customer[i].getUsername()
                    + " Customer Funds[" + i + "]:" + customer[i].getFunds());
        }
    }

    public void checkAccountBalance(int customerIndex) {
        System.out.println("Your Balance is :" + customer[customerIndex].getFunds());
    }


    public boolean withdrawFunds(int customerIndex, long funds) {
        boolean checkWithdraw = false;
        if (funds < customer[customerIndex].getFunds()) {
            System.out.println("Your Balance is: " + customer[customerIndex].getFunds() + " Rials.");
            long temp = customer[customerIndex].getFunds();
            temp -= funds;
            customer[customerIndex].setFunds(temp);
            checkWithdraw = true;
            System.out.println("After Withdraw your balance is: " + customer[customerIndex].getFunds() + " Rials.");
        } else {
            System.out.println("Your balance is not enough.");
        }
        return checkWithdraw;
    }

    public void payFunds(int customerIndex, long funds) {
        long temp = customer[customerIndex].getFunds();
        temp += funds;
        customer[customerIndex].setFunds(temp);
    }

    public boolean transferFunds(int indexOfCustomer, long funds, Long customer2Id) {
        boolean checkTransfer = false;
        for (int i = 0; i < indexOfCustomer; i++) {
            if (customer2Id == customer[i].getId()) {
                boolean check=withdrawFunds(indexOfCustomer, funds);
                if (check) {
                    payFunds(i, funds);
                }
                checkTransfer = true;
            } else {
                System.out.println("Customer 2 is not exist.");
            }
        }
        return checkTransfer;
    }
}